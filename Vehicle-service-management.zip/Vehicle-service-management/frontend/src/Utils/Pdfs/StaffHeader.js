const staffHeader = ['Email', 'Name', 'Telephone', 'Role', 'Salary', 'Gender']

export default staffHeader