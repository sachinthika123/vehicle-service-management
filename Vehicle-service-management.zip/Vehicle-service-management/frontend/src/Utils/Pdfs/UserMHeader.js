const userHeader = ['Email', 'Name', 'Telephone', 'Role', 'Gender', 'Created_at']

export default userHeader