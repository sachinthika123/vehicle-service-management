export const notiHeader = ['Description', 'From', 'toEmail', 'created_at', 'seen']
export const vehicleHeader = ['Name', 'Email','Type', 'Number', 'Font tyre', "Rear tyre", "Brand", "Last service", "Fuel type", "Milage", "Manufacture year"];
export const reviewHeader = ['Name', 'Email', 'Vehicle type', "Service date", "Note"];
export const bookingHeader = ['Name', 'Email','Service type', 'Date', 'Time', "Vehicle", "Note"];
export const employeeHeader = ['Name', 'Email','Employee type', 'Contact', 'Address', "NIC", "Age", "Salery"];;


