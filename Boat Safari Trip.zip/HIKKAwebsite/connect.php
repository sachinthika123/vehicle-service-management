<?php

$con=new mysqli('localhost','root','','hikka safariseas');

if(!$con){
    die(mysqli_error($con));

}


?>